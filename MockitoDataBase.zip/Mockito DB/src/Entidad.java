
public class Entidad {
	
	private String nombre;
	private String apellido;
	
	
	public String getNombre(){
		return nombre;
	}
	
	public String getApellido(){
		return apellido;
	}
	
	public void setNombre(String n){
		nombre = n;
	}
	
	public void setApellido(String a){
		apellido = a;
	}

}
