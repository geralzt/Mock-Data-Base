import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Coneccion {
	
	private Connection dbConeccion;
	
	//Crea la sesion en la base de datos
	public void getDBConeccion() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		dbConeccion = DriverManager.getConnection("jdbc:mysql://localhost:6666/jcg", "root", "password");
	}
	
	//Es el responsable de ejecutar el query
	public int ejecutarQuery(String query) throws ClassNotFoundException, SQLException{
		return dbConeccion.createStatement().executeUpdate(query);
	}

}
