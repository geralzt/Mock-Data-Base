
public class Servicio {
	
	private DataAccesObjet dao;
	
	public Servicio(DataAccesObjet d){
		dao = d;
	}
	
	public Entidad buscarPorId(long id){
		return dao.buscarPorId(id);
	}

}
