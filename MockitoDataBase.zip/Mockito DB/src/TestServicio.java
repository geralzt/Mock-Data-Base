import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

public class TestServicio {
	
	@Mock private DataAccesObjet dao;
	
	@Rule public MockitoRule rule = MockitoJUnit.rule();
	
	@Test
	public void testBuscarPorId(){
		MockitoAnnotations.initMocks(this);
		Servicio servicio = new Servicio(dao);
		servicio.buscarPorId(1L);
		Mockito.verify(dao).buscarPorId(1L);
	}
	
	@Test
	public void test(){
		Servicio servicio = new Servicio(dao);
		Mockito.when(dao.buscarPorId(1L)).thenReturn(crearTestEntidad());
		Entidad actual = servicio.buscarPorId(1L);
		Assert.assertEquals("Mi nombre", actual.getNombre());
		Assert.assertEquals("Mi apellido", actual.getApellido());
		Mockito.verify(dao).buscarPorId(1L);
	}
	
	private Entidad crearTestEntidad(){
		Entidad entidad = new Entidad();
		entidad.setNombre("Mi nombre");
		entidad.setApellido("Mi apellido");
		return entidad;
	}

}
