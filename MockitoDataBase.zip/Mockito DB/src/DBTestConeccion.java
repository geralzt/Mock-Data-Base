import java.sql.Connection;
import java.sql.Statement;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class DBTestConeccion {
	
	@InjectMocks private Coneccion dbConeccion;
	@Mock private Connection mockConeccion;
	@Mock private Statement mockStatement;
	
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test 
	public void testMockDBConeccion() throws Exception {
		Mockito.when(mockConeccion.createStatement()).thenReturn(mockStatement);
		Mockito.when(mockConeccion.createStatement().executeUpdate(Mockito.any())).thenReturn(1);
		int value = dbConeccion.ejecutarQuery("");
		Assert.assertEquals(value, 1);
		Mockito.verify(mockConeccion.createStatement(),Mockito.times(1));
	}
	
	

}
