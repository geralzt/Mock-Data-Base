
public class DataAccesObjet {
	
	public Entidad buscarPorId(long id){
		
		throw new UnsupportedOperationException();
	}

}
